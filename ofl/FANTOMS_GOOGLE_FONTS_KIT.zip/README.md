# Fantoms

**Fantoms** is the official retro-inspired display typeface of *The Fantoms*, created by **Gary Daggers** in 2025.

- Style: Fantoms Regular (400)
- Category: Display / Retro / Rock’n’Roll
- Based on original sketches and lettering by Gary Daggers
- Digitisation assistance from a commissioned Fiverr artist
- Licensed under the SIL Open Font License 1.1

## Links
- Project: https://www.thefantoms.com
- Support: https://paypal.me/garydaggers

