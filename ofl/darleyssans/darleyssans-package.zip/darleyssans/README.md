# Darleys Sans

**Darleys Sans** is a modern sans-serif typeface designed by Nguyễn Dương for contemporary UI and editorial design.

- Designer: Nguyễn Dương
- License: SIL Open Font License 1.1
- Category: Sans-serif
- Submitted: 2025-06-25
